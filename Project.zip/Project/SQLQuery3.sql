USE [railwaysystem]
GO

INSERT INTO [dbo].[railway_database]
           ([PNR]
           ,[Train_name]
           ,[Source]
           ,[Destination]
           ,[Departure]
           ,[Arrival]
           ,[Available_Seats])
     VALUES
           (12138
           ,'Punjab Mail'
           ,'Mumbai CSMT'
           ,'Jalgaon JL'
           ,CAST('07:35 PM' AS TIME(0))
           ,CAST('02:03 AM' AS TIME(0))
           ,30),

           (12140
           ,'Sevagram Exp'
           ,'Mumbai CSMT'
           ,'Jalgaon JL'
           ,CAST('02:56 PM' AS TIME(0))
           ,CAST('09:30 PM' AS TIME(0))
           ,50),
		   (22105
           ,'Indrayani Exp'
           ,'Mumbai CSMT'
           ,'Pune PUN'
           ,CAST('05:40 PM' AS TIME(0))
           ,CAST('09:05 AM' AS TIME(0))
           ,100),
		   (17412
           ,'Mahalaxmi Exp'
           ,'Pune PUN'
           ,'Mumbai CSMT'
           ,CAST('03:30 AM' AS TIME(0))
           ,CAST('07:25 AM' AS TIME(0))
           ,10),
		   (12655
           ,'Navjeevan Exp'
           ,'Surat ST'
           ,'Jalgaon JL'
           ,CAST('12:49 AM' AS TIME(0))
           ,CAST('06:28 AM' AS TIME(0))
		   ,0),
		   (22221
           ,'Rajdhani'
           ,'Bhopal BPL'
           ,'Anand Vihar Ter ANVT'
           ,CAST('02:00 PM' AS TIME(0))
           ,CAST('09:55 PM' AS TIME(0))
           ,0),
		   (22178
           ,'Mahanagri SF Exp'
           ,'Bhusaval BSL'
           ,'Chalisgaon CSN'
           ,CAST('03:35 PM' AS TIME(0))
           ,CAST('05:04 PM' AS TIME(0))
           ,50),
		   (16032
           ,'Andaman Exp'
           ,'New Delhi NDLS'
           ,'MGR Chennai MAS'
           ,CAST('07:00 PM' AS TIME(0))
           ,CAST('02:00 AM' AS TIME(0))
           ,50),
		   (22223
           ,'Vandebharat'
           ,'Mumbai CSMT'
           ,'Sainagar Shirdi SNSI'
           ,CAST('06:30 PM' AS TIME(0))
           ,CAST('11:30 PM' AS TIME(0))
           ,07),
		   (11099
           ,'LTT Madgaon Exp'
           ,'LTT'
           ,'Madgaon MAO'
           ,CAST('12:45 PM' AS TIME(0))
           ,CAST('11:55 AM' AS TIME(0))
           ,10)
           

GO
