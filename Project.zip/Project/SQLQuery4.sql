USE [railwaysystem]
GO

INSERT INTO [dbo].[railway_database]
           ([PNR]
           ,[Train_name]
           ,[Source]
           ,[Destination]
           ,[Departure]
           ,[Arrival]
           ,[Available_Seats])
     VALUES
           (12140
           ,'Sevagram Exp'
           ,'Mumbai CSMT'
           ,'Jalgaon JL'
           ,'2:56'
           ,'9:30'
           ,50),
		   (22105
           ,'Indrayani Exp'
           ,'Mumbai CSMT'
           ,'Pune PUN'
           ,'5:40'
           ,'9:05'
           ,100),
		   (17412
           ,'Mahalaxmi Exp'
           ,'Pune PUN'
           ,'Mumbai CSMT'
           ,'3:30'
           ,'7:25'
           ,10),
		   (12655
           ,'Navjeevan Exp'
           ,'Surat ST'
           ,'Jalgaon JL'
           ,'12:49'
           ,'6:28'
		   ,0),
		   (22221
           ,'Rajdhani'
           ,'Bhopal BPL'
           ,'Anand Vihar Ter ANVT'
           ,'2:00'
           ,'9:55'
           ,0),
		   (22178
           ,'Mahanagri SF Exp'
           ,'Bhusaval BSL'
           ,'Chalisgaon CSN'
           ,'3:35'
           ,'5:04'
           ,50),
		   (16032
           ,'Andaman Exp'
           ,'New Delhi NDLS'
           ,'MGR Chennai MAS'
           ,'7:00'
           ,'2:00'
           ,50),
		   (22223
           ,'Vandebharat'
           ,'Mumbai CSMT'
           ,'Sainagar Shirdi SNSI'
           ,'6:30'
           ,'11:30'
           ,07),
		   (11099
           ,'LTT Madgaon Exp'
           ,'LTT'
           ,'Madgaon MAO'
           ,'12:45'
           ,'11:55'
           ,10)
           

GO


