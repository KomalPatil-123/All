use railwaysystem;
create table railway_database(PNR int Primary Key,
							  Train_name varchar(50), 
							  Source varchar(60),
							  Destination varchar(60),
							  Departure time(0), 
							  Arrival time(0), 
							  Available_Seats int);